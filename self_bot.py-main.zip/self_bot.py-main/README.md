# self_bot.py
## Discord selfbot made for many purposes.

**self_bot offers 106 commands and 9 categories:**

```
> Basic
> Networking
> Discord
> Misc
> Nuking
> Abuse
> Hacks
> Other
> Voice Channels
```

<details><summary>All commands</summary>

```
    [1] [Basic]
1.    help (Shows this),
2.    rps <choice> (Rock, Paper, Scissors),
3.    dice (Roll a dice),
4.    dick "user" (Measures dick size),
5.    fact (Tells you a random fact),
6.    coin_flip (Flips a coin),
7.    poll "poll" (Creates a poll),
8.    ball "question" (Ask anything from 8ball),
9.    randint <min> <max> (Random number),
10.   icwhour ("I see who you are..."),
11.   jeriko_bomb (bum),
12.   count <num> (Counts to number),
13.   spam <amount> "message" (Spams messages),
```

```
    [2] [Networking]
1.   pscan <ip> (Port scan IP for common ports),
2.   status_code <url> (Get status code),
3.   lookup <ip> (Basic IP lookup),
4.   domain2ip <domain> (Gets ip from a domain),
```

```
    [3] [Discord]
1.   ping (Get bot's ping),
2.   clear (Clears the chat),
3.   purge <amount> (Purge messages),
4.   empty_msg (Send an empty message),
5.   edit <amount> "edit to" (Edits messages),
6.   gping <text> <user> (Ping someone secretly),
7.   fake_url <fakeurl> <realurl> (Create fake URL),
8.   create_server  <amount> "name" (Create servers),
9.   dm_friends "message" (DMs all friends),
10.  expose_bots (Tries to expose selfbots by sending "commands" like .help),
11.  gspam <amount> "group_name || random" <friend> (Creates groups and adds friend there),
12.  activity <game> (Change discord activity),
13.  channels (Shows all channels),
14.  idinfo <id> (Shows information about ID),
15.  stealpfp <download || use> <id> (Steals pfp),
16.  hypesquad <1=Bravery || 2=Brilliance || 3=Balance> (Changes Hypesquad badge),
17.  emoji_spam <amount> (Sends emojis),
18.  clone_server (Clones the server),
19.  dark (Changes theme to dark),
20.  light (Changes theme to light),
21.  firstmsg (Finds the first message),
22.  embed "message" (Sends message om embed),
23.  empty_spam <amount> (Spam empty messages),
    [3 2] [Discord]
24.  grouplock <on || off> (Automatically adds people back to the group when they leave),
```

```
    [4] [Misc]
1.   text2bin "text"(Translates text to binary),
2.   text2hex "text" (Translates text to hex),
3.   decode "text" (Decodes base64),
4.   encode "text" (Encodes text to base64),
5.   txt2qr "text" (Creates QR Code),
6.   spoilers "text" (Sends the message but with insane amount of spoilers),
7.   mysteryping <amount> (Sends a message and then it deletes the message),
8.   invisible (Goes in the invisible mode),
9.   piss <user> (Yellow wall),
10.  morsetable (Morse alphabet),
11.  brainfuck "text" (Text to Brainfuck),
12.  namestarts "text" (Finds members thats name starts with ...),
13.  tagfind <discriminator> (Show members that have specific discriminator),
14.  annoy (Annoys the chat),
15.  dm_members "message here" <delay in seconds> <verbose=on/off> (DMs all server members),
16.  gay <mention> (Measures how gay user is),
17.  txt2morse "text" (Text to morse code),
18.  roulette (Russian roulette),
19.  backup (Saves all friend and server names to a textfile),
20.  rsc (Random prntsc screenshot),
21.  rsong (Random song),
22.  counter <from> <to> (Counts to specific number),

    [4 2] [Misc]
23.   porngif (Random porn gif),
24.   boobs (Random boobs),
25.   ass (Random ass),
26.   pussy (Random pussy),
27.   thighs (Random thighs),
28.   anal (Random anal),
29.   gonewild (Random gonewild bruh),
30.   asciiart "text" <font> (Send cool ascii art),
```

```
    [5] [Nuking]
1.   mk_channels <amount> "name" (Creates channels),
2.   del_channels (Deletes all channels),
3.   rename_channels "name" (Renames all channels),
4.   nuke <create_amount> "set_name" (Makes the server a mess),
5.   mass_mention <amount> (Mass mentions members),
6.   nickall "newnick" (Changes everyones nickname),
7.   clearnickall (Resets everyones nickname),
8.   kickall (Kicks everyone from the server),
9.   react <emote> (Reacts to 20 messages),
10.  delserver (Deletes the server),
11.  broadcast <times> "message" (Sends message to every channel),
12.  raid (Requires 0 perms),
13.  pingcast (Mass mentions on every channel),
14.  auditflood <amount of logs> (Floods audit logs silently),
15.  speccast <pinghack || clear || art=text> (Special broadcasts),
16.  rolemention <amount> (Mentions roles),
```

```
    [6] [Abuse]
1.   webhook_spam <amount> "message" <url> (Spams with a webhook),
2.   delete_webhook <webhook_link> (Deletes webhook),
```

```
    [7] [Hacks]
1.   pinghack (Pings everyone),
2.   idping <user id> (Ping someone that isn't in the server),
3.   channelping <channel id> (Ping any channel outside the server),
```

```
    [8] [Other]
1.   editg "text (edited) test <- edited mark will be here" (Edit glitch),
2.   kill <user> <amount> (Makes a webhook that bullies mentioned user),
3.   type (Typing indicator everywhere),
4.   bsod (Sends a link that causes BSOD on windows machines if interacted with),
```

```
    [9] [Voice Channels]
1.   vc_join <vc id> (Joins the vc),
2.   vc_play "youtube-url" (Plays music in the vc),
3.   vc_leave (Leaves the vc),
4.   vc_pause (Pause music),
5.   vc_resume (Resume),
6.   vc_stop (Stops playing music),
```
</details>

### ***Features that make this selfbot good:***
<details><summary>See features</summary>
    
- [x] Nitro sniper
- [x] Keyword sniper
- [x] Mention AI
- [x] Backup command
- [x] 0 Permission raiding
- [x] Nuking commands
- [x] Group spammer and group locker
- [x] Unique commands

</details>
    
## **TODO:**
- [ ] More networking commands
- [ ] Backup loader
- [ ] Token nuker
- [x] Cleaner code
- [ ] Useless commands
- [x] Command aliases
- [x] Option turn off webhook logger in config file
- [ ] Token raiding
- [ ] Giveaway joiner
- [ ] Account protections
- [ ] Session Viewer
- [ ] Autobumper
- [ ] Custom commands
    
## Developer notes:
***I recommend using Pinghack on small server with under 40 members
Pinghack never works on servers with high moderation.***
    
***The command stealpfp can get your account locked for suspicious activity. To unlock it you must add your phonenumber to prevent it from happening in the future...***
    
***Remember to have common sense while using this selfbot. For example don't tell everyone that you are using a selfbot. Your account may get temporarily locked for suspicious activity.***

***I must say that using selfbots is against Discord Terms Of Service blablablabla***
    
**My Discord: wfsec#6530 (860090561682472980)**

# ***Usage:***
    
**1. Open config.**

**2. Replace "your-discord-token" with your [Discord Token](https://www.androidauthority.com/get-discord-token-3149920/)**
    
**3. Replace "your-discord-password" with your Discord Password**
    
**4. Replace "your-discord-id" with your [Discord ID](https://www.androidpolice.com/how-to-find-discord-id/)**
    
> **You can Enable/Disable Nitro Sniper, Selfbot Catcher, Keyword Stalker just by changing "true" to "false"**
    
> **To use Mention AI you must add your [OpenAI API Key](https://openai.com/api/)**
    
> **Logging webhook is where the bot logs events that are:**

> **My Discord: wfsec#6530 (860090561682472980)**
```
Deleted Messages
Messages with specific keywords
And few others
```

> **To use VC-Commands you must download ffmpeg from https://ffmpeg.org/**
