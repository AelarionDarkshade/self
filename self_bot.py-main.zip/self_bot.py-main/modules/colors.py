from colorama import Fore, init
init()

fblue = Fore.BLUE
fred = Fore.RED
fyell = Fore.YELLOW
fblac = Fore.BLACK
fwhit = Fore.WHITE
fmage = Fore.MAGENTA
fcyan = Fore.CYAN
fgree = Fore.GREEN
frese = Fore.RESET
print('')
print(f'    {fblue} Blue Fore')
print(f'    {fred} Red Fore')
print(f'    {fyell} Yellow Fore')
print(f'    {fblac} Black Fore')
print(f'    {fwhit} White Fore')
print(f'    {fmage} Magenta Fore')
print(f'    {fcyan} Cyan Fore')
print(f'    {fgree} Green Fore')
print(f'    {frese} Reset Fore')

flblue = Fore.LIGHTBLUE_EX
flred = Fore.LIGHTRED_EX
flyell = Fore.LIGHTYELLOW_EX
flwhit = Fore.LIGHTWHITE_EX
flmage = Fore.LIGHTMAGENTA_EX
flcyan = Fore.LIGHTCYAN_EX
flgree = Fore.LIGHTGREEN_EX
flblac = Fore.LIGHTBLACK_EX
print('')
print('')
print(f'    {flblue} Light Blue Fore')
print(f'    {flred} Light Red Fore')
print(f'    {flyell} Light Yellow Fore')
print(f'    {flblac} Light Black Fore')
print(f'    {flwhit} Light White Fore')
print(f'    {flmage} Light Magenta Fore')
print(f'    {flcyan} Light Cyan Fore')
print(f'    {flgree} Light Green Fore')